function [ Img_O ] = image_undistort(Img_I,K,R,t,Kd)
%Remove distortion from Img_I, using de Camera Decomposition K,T,C and
%Distortion Coeffients Kd

end

